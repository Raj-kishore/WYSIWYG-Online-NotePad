<?php
$servername = "148.66.136.137";
$username = "edusaint_drup2";
$password = "nothing";
$conn = new mysqli($servername, $username, $password);
mysqli_select_db($conn,'edusaint_drup2');



echo'
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="http://netdna.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.css" rel="stylesheet">
  <script src="http://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.js"></script> 
  <script src="http://netdna.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.js"></script> 
  <link href="http://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.8/summernote.css" rel="stylesheet">
  <script src="http://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.8/summernote.js"></script>
</head>
<body style="overflow-x:hidden;">

<div class="jumbotron" style="padding:10px;">


';

$getID = $_GET["id"]; 
$query2 = mysqli_query($conn,"SELECT * FROM abc WHERE id='".$getID."'");
$fetch2 = mysqli_fetch_assoc( $query2);
$context = $fetch2["content"];
$filex = $fetch2["fileName"];



echo'
<div class="form-group">
  <label for="usr">File Name:</label>
  <input type="text" class="form-control" id="fileN" value ="'.$filex.'">
</div>
  <div id="summernote">'.$context.'</div>
  <a  class="btn btn-info" id="insert" role="button">Save</a>
  <script>
    $(document).ready(function() {
        $("#summernote").summernote({
         height: 300,                 // set editor height
  focus: true                  // set focus to editable area after initializing summernote
        
       } );
    });
  </script>

     <script>     
      $(document).ready(function(){
      
 
       
          
          $("#insert").click(function(){
        
       
         var contentVal =  $("#summernote").summernote("code");
         var fileNameVal = $("#fileN").val();
         
            $.ajax({
         url: "./insert_file.php",
         type: "POST",
         data: { contentVal : contentVal, fileNameVal : fileNameVal } ,
         success: function (response) { 
        alert(response);
        
        }
          });
            
        
          }); 
          });
      </script>




</div>

<div class="container">
  <div class="row">
    <div class="col-sm-12">
      <h3>Files Catalouge</h3>
     
        ';
  


$query = mysqli_query($conn,"SELECT * FROM abc ORDER BY id DESC");
while($fetch = mysqli_fetch_assoc( $query)){
$fileName = $fetch['fileName'];
$fileID = $fetch['id'];

  echo'   
      <p><a href="?id='.$fileID.'">'.$fileName.'.html</a>  <a id="delete" style="color:red;" href="#!">&nbsp Delete</a> </p>

<script>
$(document).ready(function(){

$("#delete").click(function(){

if (confirm("Are you sure you want to delete this file from the database?")) {

window.location.href = "http://edusaint.com/function/deleteFile.php?id='.$fileID.'";
} else {
    // Do nothing!
}
});

});

</script>

        ';
        

}


  
  
  echo'
    </div>
  
  </div>
</div>

</body>
</html>



';

?>