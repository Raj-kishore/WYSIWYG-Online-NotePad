<?php
session_start();
$servername = "148.66.136.137";
$username = "edusaint_drup2";
$password = "nothing";
$conn = new mysqli($servername, $username, $password);
mysqli_select_db($conn,'edusaint_drup2');
$email = mysqli_real_escape_string($conn,trim($_POST['email'])); 
$pass = mysqli_real_escape_string($conn,trim($_POST['pass'])); 
$isexist = mysqli_query($conn, "SELECT * FROM drup_user_pass WHERE email = '".$email."' ");
$count = mysqli_num_rows($isexist);
if($count == 0){
    $check = mysqli_query($conn,"INSERT INTO drup_user_pass VALUES('','".$email."','".$pass."')");

        if($check){
           $id = mysql_insert_id();
           $_SESSION['uName'] = $id ;
            echo "1";   
      
        }else{
        echo "0";
        }
}else{
echo "2";
}



?>