<?php
session_start();
 
if (isset($_SESSION['uName']) && !empty($_SESSION['uName'])) {
    
  
header("Location:http://edusaint.com/function/create.php");
exit();


  }else{

echo'
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <style>
  body{
  background:#ecf0f1;
  }
  
  </style>
<script>
$(document).ready(function(){
$("#register").click(function(){
var email = $("#email").val();
var pass = $("#pass").val();
var cpass = $("#cpass").val();



if(email != "" && pass != "" && cpass != ""){

if(pass === cpass){


$.ajax({
    url:"./register_handler.php",
    type:"POST",
    data: {email:email,pass:pass},
    success: function(response){
    if(response == 1){
 
                    window.location.href = "./create.php";
                    
    }else if(response == 2){

 alert("This email is already registered.");

}else{
    alert("Something went wrong. Please try again later.");
    }
}
});




}else{

alert("Passwords are not mathcing");
}

}else{

alert("One of the fields is empty.");

}


});


$("#login").click(function(){

window.location.href = "http://edusaint.com/function/Login.php";
});






});
</script>



</head>
<body>


<div class="container">
  <div style="background: #ecf0f1;" class="jumbotron">
   <div style="float:left;"> <h1 style="color: #34495e;">Online notepad</h1></div><div style="float:left;"><h6>beta</h6></div>
<div style="clear: both;"></div>


    <br/>
     <form>

  <div class="input-group">
    <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
    <input id="email" type="text" class="form-control" name="email" placeholder="Email">
  </div>
<br/>
  <div class="input-group">
    <span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
    <input id="pass" type="password" class="form-control" name="password" placeholder="Password">
  </div>
<br/>

 <div class="input-group">
    <span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
    <input id="cpass" type="password" class="form-control" name="Confirm password" placeholder="Confirm Password">
  </div>
<br/>

  <button type="button" id="register" class="btn btn-primary">Register</button>

  <button type="button" id="login" class="btn btn-success">Log in</button>

</form> 
<br/><br/><br/>
<div style="width:100%; text-align: right;">
 <h3 style="color: #34495e;">Write and save your documents</h3>
 <h4 style="color: #34495e;">with a rich text editor</h4>
 <h5 style="color: #34495e;">Produced by Nexfort Wizard</h5>
 <h6 style="color: #34495e;">&copy; Copyrigth 2017 | All rigths reserved</h6>
 <h6 style="color: #34495e;">Privacy | Pricing </h6>
</div>
<br/>
</div>



         
</div>

</body>
</html>
';
}

?>