<?php
session_start();

if (isset($_SESSION['uName']) && !empty($_SESSION['uName'])) {

//logged in





$servername = "148.66.136.137";
$username = "edusaint_drup2";
$password = "nothing";
$conn = new mysqli($servername, $username, $password);
mysqli_select_db($conn,'edusaint_drup2');




echo'
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Welcome to WYSIWYG</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">


<link href="http://netdna.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.css" rel="stylesheet"> 
<script src="http://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.js"></script> 
<script src="http://netdna.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.js"></script> 



<!-- include summernote css/js-->
<link href="http://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.8/summernote.css" rel="stylesheet">
<script src="http://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.8/summernote.js"></script>

<style>



#image{
position: fixed;
display:none;
  width:100px;
  text-align:center;
  background-color:#3498db;
  color:#fff;
  padding:10px;
  border:5px solid #2980b9;
  z-index:200;
  margin: 5% auto;
  left: 0;
  right: 0;
}
#nav{
width:100%;
padding:10px;
background:#3498db;
text-align:center;
color:#fff;
font-size:28px;
}

#footer{
width:100%;
padding:10px;
background:#34495e;
text-align:center;
color:#ecf0f1;
font-size:11px;
}
</style>


</head>
<body style="overflow-x:hidden;">


<div id="nav">WYSIWYG Online Notepad
<h6> <a style="color:#fff;" href="logout.php"><img width="20px" src="./img/sign-out-option.png"/></a></h6> </div>






<div id="image">Loading...</div>


<div class="jumbotron" style="padding:10px;">


';

$getID = $_GET["id"]; 
$query2 = mysqli_query($conn,"SELECT * FROM abc WHERE id='".$getID."'");
$fetch2 = mysqli_fetch_assoc( $query2);
$context = mysqli_real_escape_string($conn,trim($fetch2["content"]));


$filex = $fetch2["fileName"];


echo'
<div class="form-group">
  <label for="usr">File Name:</label>
  <input type="text" class="form-control" id="fileN" value ="'.$filex.'">
</div>
  <div id="summernote"></div>
  <a  class="btn btn-info" id="insert" role="button">Save</a>


  <script>
    $(document).ready(function() {
    
var conx = "'.$context.'";
$("#summernote").html(conx);
    $("#summernote").summernote({
height : 300
});
    });
  </script>

     <script>     
      $(document).ready(function(){
      
 
       
          
          $("#insert").click(function(){

              var contentVal = $("#summernote").summernote("code");;


         var fileNameVal = $("#fileN").val();
var userid = '.$_SESSION['uName'].';
         
            $.ajax({
         url: "./insert_file.php",
         type: "POST",
         data: { contentVal : contentVal, fileNameVal : fileNameVal, userid : userid  } ,

      cache: false,
    beforeSend: function(){
        $("#image").show();
    },
    complete: function(){
        $("#image").hide();
    },

         success: function (response) { 
        alert(response);
        
        }
          });
            
        
          }); 
          });
      </script>




</div>

<div class="container">
  <div class="row">
    <div class="col-sm-12">
      <h3>Files Catalouge</h3>
     
        ';
  


$query = mysqli_query($conn,"SELECT * FROM abc WHERE userID='".$_SESSION['uName']."' ORDER BY id DESC");
while($fetch = mysqli_fetch_assoc( $query)){
$fileName = $fetch['fileName'];
$fileID = $fetch['id'];

  echo'   
      <p><a href="?id='.$fileID.'">'.$fileName.'.html</a> &nbsp &nbsp <a onClick="del('.$fileID.')" style="color:red;" href="#!"> Delete</a> </p>

<script>
function del(idd){



if (confirm("Are you sure you want to delete the file from the database?")) {

window.location.href = "http://edusaint.com/function/deleteFile.php?id="+idd;
} else {
    // Do nothing!
}




}





</script>

        ';
        

}


  
  
  echo'
    </div>
  
  </div>
</div>
<br/>
<br/>


<div id="footer">
<div>Copyright 2017 | All rights reserved</div>
<div>Nexfort Wizard Productions</div>
<div>Privacy | Pricing</div>
<div>Contact: raj.maharana.94@gmail.com</div>

</div>

</body>
</html>



';


}else{

header('location: http://edusaint.com/function/Login.php?message=please_log_in');
exit();

}

?>