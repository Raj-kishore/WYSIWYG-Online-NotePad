<?php

session_start();
$servername = "148.66.136.137";
$username = "edusaint_drup2";
$password = "nothing";
$conn = new mysqli($servername, $username, $password);
mysqli_select_db($conn,'edusaint_drup2');

$content = mysqli_real_escape_string($conn,trim($_POST['contentVal'])); 
$filename = mysqli_real_escape_string($conn,trim($_POST['fileNameVal'])); 

$userid = mysqli_real_escape_string($conn,trim($_POST['userid'])); 



$search = array('/','\\',':',';','!','@','#','$','%','^','*','(',')','_','+','=','|','{','}','[',']','"',"'",'<','>',',','?','~','`','&',' ','.');
$filename = strtolower(str_replace($search, '-', $filename));

$filename = preg_replace('/-+/', '-', $filename);//removes duplicate dashes "---" to single "-"

$filename = rtrim($filename,'-'); // removes the last '-' if in case exists.






$myfile = fopen(strtolower("./files/".$filename.".html") , "w") or die("Unable to open file!");
$txt = $content;
fwrite($myfile, $txt);
fclose($myfile);

// first create file and close files, then call insert query otherwise $filename and $content values are deprecated after it has been inserted.

$ifexist = mysqli_query($conn,"SELECT fileName FROM abc WHERE fileName = '".$filename."' AND userID='".$_SESSION['uName']."'");
$count = mysqli_num_rows($ifexist);
if($count == 0){


$query = mysqli_query($conn, "INSERT INTO abc VALUES('','".$filename."','".$content."','".$userid."')");
echo "New file created successfully.";

}else{

$query = mysqli_query($conn, "UPDATE abc SET content = '".$content."' WHERE fileName = '".$filename."' AND userID='".$_SESSION['uName']."' ");
echo "Existing file update is successful.";


}






?>