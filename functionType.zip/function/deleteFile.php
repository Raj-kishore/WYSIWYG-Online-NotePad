<?php
$servername = "148.66.136.137";
$username = "edusaint_drup2";
$password = "nothing";
$conn = new mysqli($servername, $username, $password);
mysqli_select_db($conn,'edusaint_drup2');

$getID = $_GET['id'];


$query = mysqli_query($conn, "DELETE FROM abc WHERE id ='".$getID."'");


header("Location: http://edusaint.com/function/create.php");
die();









?>