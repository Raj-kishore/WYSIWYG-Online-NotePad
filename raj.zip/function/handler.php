<?php
session_start();



$servername = "148.66.136.137";
$username = "edusaint_drup2";
$password = "nothing";
$conn = new mysqli($servername, $username, $password);
mysqli_select_db($conn,'edusaint_drup2');

$email = mysqli_real_escape_string($conn,trim($_POST['email'])); 


$pass = mysqli_real_escape_string($conn,trim($_POST['pass'])); 


$check = mysqli_query($conn,"SELECT * FROM drup_user_pass WHERE email='".$email."' AND pass = '".$pass."'");
$count = mysqli_num_rows($check);
if($count == 1){
echo "1";
$_SESSION['uName'] = $email;
}else{
echo "0";
}





?>